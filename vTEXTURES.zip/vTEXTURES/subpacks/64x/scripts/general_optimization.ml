public class OptimizarInicio: MonoBehavior{

	private function Buttons(){
	
	new Vertex buttons;
	new bool optimization;
	
	buttons.GetArchive(is(not)<new Vector2(get.referencial.button or gui.components: position)>);
	
	buttons.optmization = true;
	}
	
	referencial void Update(){
	
	if(game.get.loading.optimization.rotate == true){
													
							Delete(game.get.pixels.screen[64 * 64 /  Screen.Time.deltaTime(eulerRotation as before)] ); 	

					or else(optimization[not true or false too]){
					game.get.archive(XML<GetFunction>(): crashGame() or public new function(if(not)))
					}
					else{
			Delete(game.get.pixels.screen[64 * 64 /  Screen.Time.deltaTime(eulerRotation as before)] ); 	

					or else(optimization[not true or also false]){
					game.get.archive(XML<GetFunction>(): crashGame() or public new function(if(not)))
					}
				}
			}	
		}
	}public class 2: MonoBehavior{

	private function Buttons(){
	
	new Vertex buttons;
	new bool optimization;
	
	buttons.GetArchive(is(not)<new Vector2(get.referencial.button or gui.components: position)>);
	
	buttons.optmization = true;
	}
	
	referencial void Update(){
	
	if(game.get.loading.optimization.rotate == true){
													
							Delete(game.get.pixels.screen[64 * 64 /  Screen.Time.deltaTime(eulerRotation as before)] ); 	

					or else(optimization[not true or false too]){
					game.get.archive(XML<GetFunction>(): crashGame() or public new function(if(not)))
					}
					else{
			Delete(game.get.pixels.screen[64 * 64 /  Screen.Time.deltaTime(eulerRotation as before)] ); 	

					or else(optimization[not true or false too]){
					game.get.archive(XML<GetFunction>(): crashGame() or public new function(if(not)))
					}
				}
			}	
		}
	}